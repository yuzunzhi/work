#!/bin/bash

killall redis-server
