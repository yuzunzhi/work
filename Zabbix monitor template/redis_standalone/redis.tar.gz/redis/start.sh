#!/bin/bash

./redis-server conf/redis-6379.conf
